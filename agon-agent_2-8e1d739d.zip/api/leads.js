import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('leads').select('*').order('id', { ascending: false }).limit(50);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { name, email, phone, garage_name, message, type } = req.body || {};
      if (!name || !email) return res.status(400).json({ error: 'Nom et email requis' });
      const { data, error } = await supabase
        .from('leads')
        .insert({ name, email, phone: phone || null, garage_name: garage_name || null, message: message || null, type: type || 'demo' })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API leads error:', err);
    res.status(500).json({ error: err.message });
  }
}
