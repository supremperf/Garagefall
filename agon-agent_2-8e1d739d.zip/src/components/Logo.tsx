export default function Logo({ size = 40, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5 select-none">
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="GarageFall logo">
        <defs>
          <linearGradient id="gf-mark" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#FFB800" />
            <stop offset="0.5" stopColor="#FF6A1A" />
            <stop offset="1" stopColor="#E63E00" />
          </linearGradient>
          <linearGradient id="gf-sheen" x1="6" y1="4" x2="42" y2="20" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#fff" stopOpacity="0.35" />
            <stop offset="1" stopColor="#fff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <rect x="1.5" y="1.5" width="45" height="45" rx="13" fill="#0C0D11" />
        <rect x="1.5" y="1.5" width="45" height="45" rx="13" stroke="url(#gf-mark)" strokeWidth="2.5" />
        <rect x="4" y="4" width="40" height="40" rx="11" fill="url(#gf-sheen)" opacity="0.5" />
        <path d="M31 15.5c-5.6 0-10 4-10 9 0 5.2 4.2 9.1 9.6 9.1 2.7 0 5-1 6.4-2.6v-7h-6.9v3.7h3v2.1c-.8.6-1.9.9-3 .9-3.2 0-5.6-2.4-5.6-5.6 0-3.1 2.4-5.4 5.6-5.4 1.7 0 3.1.6 4.1 1.7l2.7-2.7c-1.7-1.6-4.1-2.7-6.9-2.7z" fill="url(#gf-mark)" />
        <path d="M33.5 32.5l2.1 2.1 4.2-4.2" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      {withText && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[1.35rem] tracking-tight text-white" style={{ fontWeight: 700 }}>
            Garage<span className="gradient-text">Fall</span>
          </span>
          <span className="text-[0.6rem] font-semibold uppercase tracking-[0.28em] text-zinc-500 mt-1">
            Garage OS
          </span>
        </span>
      )}
    </span>
  );
}
