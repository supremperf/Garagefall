import { useEffect, useState } from 'react';
import { Check, Download, Sparkles } from 'lucide-react';
import { SectionTag, Reveal, Skeleton } from './ui';
import { DOWNLOAD_URL } from '../lib/constants';

type Plan = {
  id: number; name: string; price_monthly: number; price_yearly: number;
  description: string; features: string[]; is_popular: boolean; badge: string | null; cta_text: string;
};

export default function Pricing() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [yearly, setYearly] = useState(true);

  useEffect(() => {
    fetch('/api/pricing')
      .then((r) => { if (!r.ok) throw new Error('Erreur'); return r.json(); })
      .then((d) => { if (Array.isArray(d)) setPlans(d); })
      .catch(() => setError('Impossible de charger les tarifs pour le moment.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section id="tarifs" className="relative scroll-mt-20 border-y border-white/5 bg-[#0B0C10] py-20 md:py-28">
      <div className="pointer-events-none absolute top-20 left-1/2 h-[360px] w-[760px] -translate-x-1/2 rounded-full bg-orange-600/10 blur-[130px]" aria-hidden />
      <div className="relative mx-auto max-w-6xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Tarifs</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">
            Un tarif clair, <span className="gradient-text">rentabilisé dès la 1ʳᵉ semaine</span>
          </h2>
          <p className="mt-4 text-zinc-400">Essai gratuit de 14 jours sur toutes les offres. Sans engagement, sans carte bancaire, sans frais cachés.</p>
          <div className="mt-7 inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1">
            <button onClick={() => setYearly(false)} className={`rounded-full px-5 py-2 text-sm font-semibold transition-all ${!yearly ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'}`}>Mensuel</button>
            <button onClick={() => setYearly(true)} className={`flex items-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition-all ${yearly ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'}`}>
              Annuel <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[0.65rem] font-bold text-emerald-300">-20 %</span>
            </button>
          </div>
        </Reveal>

        {loading ? (
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-[420px]" />)}
          </div>
        ) : error ? (
          <p className="mt-12 rounded-xl border border-red-500/30 bg-red-500/10 p-5 text-center text-sm text-red-300">{error}</p>
        ) : (
          <div className="mt-12 grid items-stretch gap-5 md:grid-cols-3">
            {plans.map((p, i) => {
              const price = yearly ? Math.round(Number(p.price_yearly) / 12) : Number(p.price_monthly);
              return (
                <Reveal key={p.id} delay={i * 0.08} className="h-full">
                  <div className={`relative flex h-full flex-col rounded-2xl p-[1.5px] ${p.is_popular ? 'bg-gradient-to-b from-amber-400 via-orange-500 to-orange-700 shadow-[0_24px_80px_-24px_rgba(255,106,26,0.5)]' : 'bg-white/10'}`}>
                    {p.is_popular && (
                      <span className="absolute -top-3.5 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-600 px-4 py-1 text-[0.68rem] font-bold uppercase tracking-wider whitespace-nowrap text-black">
                        <Sparkles size={12} /> Le plus choisi
                      </span>
                    )}
                    <div className="flex h-full flex-col rounded-[15px] bg-[#101116] p-7">
                      <p className="text-sm font-bold uppercase tracking-[0.16em] text-zinc-400">{p.name}</p>
                      {p.badge && <p className="mt-1 text-xs font-semibold text-orange-300">{p.badge}</p>}
                      <div className="mt-4 flex items-end gap-1.5">
                        <span className="font-display text-[2.75rem] leading-none font-bold text-white">{price} €</span>
                        <span className="pb-1.5 text-sm text-zinc-500">/ mois{yearly ? ' HT*' : ' HT'}</span>
                      </div>
                      <p className="mt-2 text-sm text-zinc-400">{p.description}</p>
                      <ul className="mt-6 flex-1 space-y-3 border-t border-white/5 pt-6">
                        {(p.features ?? []).map((f) => (
                          <li key={f} className="flex items-start gap-2.5 text-sm text-zinc-300">
                            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400"><Check size={12} strokeWidth={3} /></span>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className={p.is_popular ? 'btn-primary mt-7 w-full justify-center' : 'btn-ghost mt-7 w-full justify-center'}>
                        <Download size={16} strokeWidth={2.5} /> {p.cta_text || 'Télécharger'}
                      </a>
                      <p className="mt-2.5 text-center text-xs text-zinc-500">Essai 14 jours gratuit</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        )}
        <p className="mt-8 text-center text-xs text-zinc-500">* Facturation annuelle. TVA en sus. Reprise de données et formation de démarrage incluses sur toutes les offres.</p>
      </div>
    </section>
  );
}
