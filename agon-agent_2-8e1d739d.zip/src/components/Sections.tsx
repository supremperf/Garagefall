import { useEffect, useRef, useState } from 'react';
import { useInView } from 'framer-motion';
import {
  CalendarClock, Users, ClipboardList, Receipt, Package, BellRing, BarChart3,
  ShieldCheck, Check, X, Download, MonitorDown, Database, CalendarCheck2, TrendingUp
} from 'lucide-react';
import { SectionTag, Reveal, Skeleton } from './ui';
import { DOWNLOAD_URL, DOWNLOAD_LABEL } from '../lib/constants';

type Stat = { id: number; label: string; value_numeric: number; value_suffix: string; description: string };

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1600;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value]);
  const formatted = display.toLocaleString('fr-FR').replace(/ /g, ' ');
  return <span ref={ref}>{formatted}{suffix}</span>;
}

export function StatsBar() {
  const [stats, setStats] = useState<Stat[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch('/api/stats')
      .then((r) => r.json())
      .then((d) => { if (Array.isArray(d)) setStats(d); })
      .catch(() => undefined)
      .finally(() => setLoading(false));
  }, []);
  const garages = ['Garage Martin — Lyon', 'Auto Prestige — Bordeaux', 'Garage du Centre — Nantes', 'Méca Express — Lille', 'Atelier Rive Sud — Marseille', 'Garage Volta — Paris', 'Auto Concept — Toulouse', 'Garage des Alpes — Grenoble'];
  return (
    <section className="relative border-y border-white/5 bg-[#0B0C10]/80 py-12">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        {loading ? (
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24" />)}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
            {stats.map((s, i) => (
              <Reveal key={s.id} delay={i * 0.08} className="text-center lg:text-left">
                <p className="font-display text-3xl font-bold text-white md:text-4xl"><Counter value={s.value_numeric} suffix={s.value_suffix} /></p>
                <p className="mt-1 text-sm font-semibold text-orange-300">{s.label}</p>
                <p className="mt-0.5 text-xs text-zinc-500">{s.description}</p>
              </Reveal>
            ))}
          </div>
        )}
        <div className="relative mt-10 overflow-hidden" aria-hidden>
          <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#0B0C10] to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#0B0C10] to-transparent" />
          <div className="marquee flex w-max items-center gap-10 whitespace-nowrap">
            {[...garages, ...garages].map((g, i) => (
              <span key={i} className="flex items-center gap-10 text-sm font-medium text-zinc-600">
                {g} <i className="h-1 w-1 rounded-full bg-orange-500/60" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const FEATURES = [
  { icon: CalendarClock, title: 'Planning intelligent', desc: 'Glisser-déposer, multi-ponts, multi-mécaniciens et prise de RDV en ligne synchronisée en temps réel.', tag: 'Atelier' },
  { icon: Users, title: 'Clients & véhicules', desc: 'Fiches complètes, historique, VIN décodé automatiquement et recherche instantanée.', tag: 'Fidélisation' },
  { icon: ClipboardList, title: 'Ordres de réparation', desc: 'OR numériques avec photos, contrôles, signatures électroniques et suivi du temps passé.', tag: 'Atelier' },
  { icon: Receipt, title: 'Devis & facturation', desc: 'Devis, factures conformes, avoirs, acomptes et encaissements multi-moyens en 1 clic.', tag: 'Gestion' },
  { icon: Package, title: 'Stock pièces', desc: 'Références, fournisseurs, seuils d’alerte et commandes automatiques. Fini les ruptures.', tag: 'Gestion' },
  { icon: BellRing, title: 'Rappels automatiques', desc: 'SMS et emails auto : rappel de RDV, entretien à prévoir, CT à venir, révision due.', tag: 'Fidélisation' },
  { icon: BarChart3, title: 'Pilotage & rapports', desc: 'CA, marges, productivité, panier moyen : 25 rapports prêts pour piloter votre rentabilité.', tag: 'Pilotage' },
  { icon: ShieldCheck, title: 'Multi-postes & sauvegarde', desc: 'Accueil, atelier, bureau : travaillez à plusieurs avec sauvegarde cloud chiffrée.', tag: 'Sécurité' },
];

export function Features() {
  return (
    <section id="fonctionnalites" className="relative scroll-mt-20 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Fonctionnalités</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">
            Tout votre garage, <span className="gradient-text">dans un seul logiciel</span>
          </h2>
          <p className="mt-4 text-zinc-400">Huit modules intégrés qui partagent les mêmes données. Une seule saisie, zéro ressaisie, zéro papier perdu.</p>
        </Reveal>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={(i % 4) * 0.07}>
              <div className="group h-full rounded-2xl border border-white/10 bg-[#101116] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-orange-500/45 hover:shadow-[0_20px_60px_-20px_rgba(255,106,26,0.35)]">
                <div className="flex items-start justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400/20 to-orange-600/20 text-orange-400 ring-1 ring-orange-500/30 transition-colors group-hover:from-amber-400 group-hover:to-orange-600 group-hover:text-black">
                    <f.icon size={22} />
                  </span>
                  <span className="rounded-full bg-white/5 px-2.5 py-1 text-[0.62rem] font-semibold text-zinc-500 ring-1 ring-white/10">{f.tag}</span>
                </div>
                <h3 className="font-display mt-5 text-[1.05rem] font-bold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-10 text-center">
          <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className="btn-primary btn-lg">
            <Download size={18} strokeWidth={2.5} /> {DOWNLOAD_LABEL} — gratuit 14 jours
          </a>
        </Reveal>
      </div>
    </section>
  );
}

const COMPARE_ROWS: { label: string; gf: boolean; excel: boolean | 'partiel'; other: boolean | 'partiel' }[] = [
  { label: 'Installation en 5 minutes sur Windows', gf: true, excel: false, other: 'partiel' },
  { label: 'Planning glisser-déposer multi-mécaniciens', gf: true, excel: false, other: 'partiel' },
  { label: 'Rappels SMS automatiques anti-lapins', gf: true, excel: false, other: false },
  { label: 'Devis, ordre et facture en 1 clic', gf: true, excel: false, other: 'partiel' },
  { label: 'Stock pièces temps réel + alertes', gf: true, excel: 'partiel', other: 'partiel' },
  { label: 'Reprise de vos données offerte', gf: true, excel: false, other: false },
  { label: 'Support 7j/7 en français', gf: true, excel: false, other: 'partiel' },
  { label: 'Sans engagement, mises à jour incluses', gf: true, excel: false, other: false },
];

function Cell({ v, highlight }: { v: boolean | 'partiel'; highlight?: boolean }) {
  if (v === true) return <span className={`mx-auto flex h-7 w-7 items-center justify-center rounded-full ${highlight ? 'bg-gradient-to-br from-amber-400 to-orange-600 text-black' : 'bg-emerald-500/15 text-emerald-400'}`}><Check size={15} strokeWidth={3} /></span>;
  if (v === 'partiel') return <span className="mx-auto block w-fit rounded-full bg-white/5 px-2.5 py-1 text-[0.65rem] font-semibold text-zinc-400 ring-1 ring-white/10">Partiel</span>;
  return <span className="mx-auto flex h-7 w-7 items-center justify-center rounded-full bg-red-500/10 text-red-400/70"><X size={14} strokeWidth={2.5} /></span>;
}

export function Comparison() {
  return (
    <section id="avantages" className="relative scroll-mt-20 border-y border-white/5 bg-[#0B0C10] py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Pourquoi GarageFall</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">
            Fini Excel, le papier <span className="gradient-text">et les logiciels d’un autre âge</span>
          </h2>
          <p className="mt-4 text-zinc-400">Nous avons interrogé 400 garagistes pour concevoir l’outil qu’ils attendaient vraiment.</p>
        </Reveal>
        <Reveal delay={0.1} className="mt-12">
          <div className="overflow-x-auto rounded-2xl border border-white/10">
            <table className="w-full min-w-[640px] border-collapse bg-[#101116] text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-5 py-4 text-left font-semibold text-zinc-400">Critère</th>
                  <th className="bg-gradient-to-b from-orange-500/15 to-transparent px-4 py-4 text-center">
                    <span className="font-display font-bold text-white">Garage<span className="gradient-text">Fall</span></span>
                    <span className="mx-auto mt-1 block w-fit rounded-full bg-gradient-to-r from-amber-400 to-orange-600 px-2.5 py-0.5 text-[0.6rem] font-bold uppercase tracking-wider text-black">Recommandé</span>
                  </th>
                  <th className="px-4 py-4 text-center font-semibold text-zinc-500">Excel / Papier</th>
                  <th className="px-4 py-4 text-center font-semibold text-zinc-500">Autres logiciels</th>
                </tr>
              </thead>
              <tbody>
                {COMPARE_ROWS.map((r) => (
                  <tr key={r.label} className="border-b border-white/5 last:border-0 hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5 font-medium text-zinc-200">{r.label}</td>
                    <td className="bg-orange-500/[0.05] px-4 py-3.5 text-center"><Cell v={r.gf} highlight /></td>
                    <td className="px-4 py-3.5 text-center"><Cell v={r.excel} /></td>
                    <td className="px-4 py-3.5 text-center"><Cell v={r.other} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

const STEPS = [
  { icon: MonitorDown, num: '01', title: 'Téléchargez', desc: 'Un seul fichier EXE, 3 minutes chrono. Aucune compétence technique requise.', time: '3 min' },
  { icon: Database, num: '02', title: 'Importez vos données', desc: 'Clients, véhicules, stock : on reprend tout gratuitement depuis Excel ou votre ancien outil.', time: 'Offert' },
  { icon: CalendarCheck2, num: '03', title: 'Planifiez', desc: 'Vos rendez-vous, vos OR et vos rappels SMS tournent dès le premier jour.', time: 'Jour 1' },
  { icon: TrendingUp, num: '04', title: 'Facturez & pilotez', desc: 'Devis, factures, encaissements et rapports : votre rentabilité grimpe semaine après semaine.', time: '+32 % CA' },
];

export function Workflow() {
  return (
    <section className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Démarrage express</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem]">
            Opérationnel <span className="gradient-text">en un après-midi</span>
          </h2>
        </Reveal>
        <div className="relative mt-12 grid gap-4 md:grid-cols-4">
          <div className="absolute top-10 right-[12%] left-[12%] hidden h-px bg-gradient-to-r from-transparent via-orange-500/50 to-transparent md:block" aria-hidden />
          {STEPS.map((s, i) => (
            <Reveal key={s.num} delay={i * 0.1}>
              <div className="relative h-full rounded-2xl border border-white/10 bg-[#101116] p-6">
                <span className="font-display absolute top-4 right-5 text-4xl font-bold text-white/5">{s.num}</span>
                <span className="relative flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 text-black shadow-lg shadow-orange-600/30">
                  <s.icon size={22} />
                </span>
                <p className="mt-4 text-[0.65rem] font-bold uppercase tracking-[0.2em] text-orange-400">Étape {s.num} — {s.time}</p>
                <h3 className="font-display mt-1.5 text-lg font-bold text-white">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
