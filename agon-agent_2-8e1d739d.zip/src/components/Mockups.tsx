import {
  LayoutDashboard, CalendarDays, Users, Car, ClipboardList, Receipt, Package,
  BarChart3, Search, Bell, ChevronLeft, ChevronRight, Plus, Phone, Wrench, FileText, Check, Clock
} from 'lucide-react';

const NAV = [
  { icon: LayoutDashboard, label: 'Tableau de bord', active: true },
  { icon: CalendarDays, label: 'Planning', active: false },
  { icon: Users, label: 'Clients', active: false },
  { icon: Car, label: 'Véhicules', active: false },
  { icon: ClipboardList, label: 'Ordres réparation', active: false },
  { icon: Receipt, label: 'Facturation', active: false },
  { icon: Package, label: 'Stock pièces', active: false },
  { icon: BarChart3, label: 'Rapports', active: false },
];

function Sidebar() {
  return (
    <div className="hidden w-48 shrink-0 flex-col border-r border-white/5 bg-[#0B0C11] p-3 md:flex">
      <div className="flex items-center gap-2 px-2 py-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 text-sm font-black text-black">G</span>
        <span className="text-[0.8rem] font-bold text-white">Garage<span className="text-orange-400">Fall</span></span>
      </div>
      <div className="mt-3 space-y-0.5">
        {NAV.map((n) => (
          <div key={n.label} className={`flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[0.72rem] font-medium ${n.active ? 'bg-gradient-to-r from-orange-500/25 to-amber-500/10 text-orange-300 ring-1 ring-orange-500/30' : 'text-zinc-500'}`}>
            <n.icon size={14} />{n.label}
          </div>
        ))}
      </div>
      <div className="mt-auto rounded-xl border border-white/5 bg-white/[0.03] p-3">
        <p className="text-[0.65rem] font-semibold text-zinc-400">Objectif mensuel</p>
        <p className="mt-0.5 text-sm font-bold text-white">82 %</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-[82%] rounded-full bg-gradient-to-r from-amber-400 to-orange-500" />
        </div>
      </div>
    </div>
  );
}

function Topbar({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="flex items-center gap-3 border-b border-white/5 bg-[#0E0F14] px-4 py-2.5">
      <div>
        <p className="text-[0.8rem] font-bold text-white">{title}</p>
        <p className="text-[0.65rem] text-zinc-500">{subtitle}</p>
      </div>
      <div className="ml-auto hidden items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-[0.7rem] text-zinc-500 sm:flex">
        <Search size={12} /> Rechercher…
      </div>
      <span className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-zinc-400">
        <Bell size={14} /><i className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-orange-500" />
      </span>
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 text-[0.7rem] font-black text-black">MD</span>
    </div>
  );
}

const shell = 'flex h-[480px] sm:h-[540px] bg-[#0E0F14] text-left overflow-hidden';
const main = 'flex min-w-0 flex-1 flex-col';
const body = 'flex-1 overflow-hidden p-3 sm:p-4';

export default function DashboardMockup() {
  const kpis = [
    { label: 'CA du mois', value: '48 290 €', delta: '+12,4 %', up: true },
    { label: 'Véhicules en atelier', value: '18', delta: '+3 aujourd’hui', up: true },
    { label: 'RDV aujourd’hui', value: '12', delta: '4 restants', up: true },
    { label: 'Factures en attente', value: '3 240 €', delta: '6 factures', up: false },
  ];
  const rows = [
    { plate: 'GH-204-KL', car: 'Peugeot 3008', client: 'S. Bernard', mec: 'Karim', status: 'En cours', cls: 'bg-sky-500/15 text-sky-300 ring-sky-500/30', pct: 65 },
    { plate: 'AB-913-XZ', car: 'Renault Clio V', client: 'L. Moreau', mec: 'Sophie', status: 'Diagnostic', cls: 'bg-violet-500/15 text-violet-300 ring-violet-500/30', pct: 30 },
    { plate: 'FR-555-EV', car: 'Tesla Model 3', client: 'K. Diallo', mec: 'Mehdi', status: 'En attente pièces', cls: 'bg-amber-500/15 text-amber-300 ring-amber-500/30', pct: 45 },
    { plate: 'TM-882-QQ', car: 'Dacia Duster', client: 'M. Petit', mec: 'Julien', status: 'Terminé', cls: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30', pct: 100 },
    { plate: 'VX-310-RT', car: 'BMW X1', client: 'A. Rousseau', mec: 'Karim', status: 'En cours', cls: 'bg-sky-500/15 text-sky-300 ring-sky-500/30', pct: 72 },
  ];
  return (
    <div className={shell}>
      <Sidebar />
      <div className={main}>
        <Topbar title="Bonjour, Martin" subtitle="Vendredi 13 novembre 2026 — Voici votre journée d’atelier" />
        <div className={body}>
          <div className="grid grid-cols-2 gap-2.5 xl:grid-cols-4">
            {kpis.map((k) => (
              <div key={k.label} className="rounded-xl border border-white/5 bg-[#12131A] p-3">
                <p className="text-[0.62rem] font-medium text-zinc-500">{k.label}</p>
                <p className="font-display mt-1 text-lg font-bold text-white">{k.value}</p>
                <p className={`mt-0.5 text-[0.65rem] font-semibold ${k.up ? 'text-emerald-400' : 'text-amber-400'}`}>{k.delta}</p>
              </div>
            ))}
          </div>
          <div className="mt-2.5 grid gap-2.5 xl:grid-cols-5">
            <div className="rounded-xl border border-white/5 bg-[#12131A] p-3 xl:col-span-2">
              <div className="flex items-center justify-between">
                <p className="text-[0.7rem] font-bold text-white">Activité — 14 jours</p>
                <span className="rounded-md bg-white/5 px-2 py-0.5 text-[0.6rem] text-zinc-500">CA / RDV</span>
              </div>
              <div className="mt-3 flex h-24 items-end gap-1.5">
                {[40, 62, 48, 75, 58, 88, 70, 95, 64, 82, 74, 100, 86, 92].map((h, i) => (
                  <span key={i} className={`flex-1 rounded-t ${i === 11 ? 'bg-gradient-to-t from-orange-600 to-amber-400' : 'bg-white/10'}`} style={{ height: `${h}%` }} />
                ))}
              </div>
            </div>
            <div className="overflow-hidden rounded-xl border border-white/5 bg-[#12131A] xl:col-span-3">
              <p className="border-b border-white/5 px-3 py-2 text-[0.7rem] font-bold text-white">Interventions en cours</p>
              {rows.map((r) => (
                <div key={r.plate} className="flex items-center gap-2.5 border-b border-white/5 px-3 py-2 last:border-0">
                  <span className="rounded border border-white/15 bg-white px-1.5 py-0.5 font-mono text-[0.6rem] font-bold text-zinc-900">{r.plate}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[0.68rem] font-semibold text-zinc-200">{r.car}</span>
                    <span className="block text-[0.6rem] text-zinc-500">{r.client} • {r.mec}</span>
                  </span>
                  <span className="hidden h-1 w-16 overflow-hidden rounded-full bg-white/10 sm:block"><span className="block h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500" style={{ width: `${r.pct}%` }} /></span>
                  <span className={`rounded-full px-2 py-0.5 text-[0.58rem] font-bold ring-1 ${r.cls}`}>{r.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PlanningMockup() {
  const days = ['Lun 9', 'Mar 10', 'Mer 11', 'Jeu 12', 'Ven 13', 'Sam 14'];
  const cols: { t: string; l: string; s: string }[][] = [
    [{ t: '08:30', l: 'Vidange 3008', s: 'border-sky-500/40 bg-sky-500/10' }, { t: '11:00', l: 'Freins Clio V', s: 'border-orange-500/40 bg-orange-500/10' }, { t: '15:30', l: 'CT Duster', s: 'border-emerald-500/40 bg-emerald-500/10' }],
    [{ t: '09:00', l: 'Diag Tesla', s: 'border-violet-500/40 bg-violet-500/10' }, { t: '13:30', l: 'Distri 208', s: 'border-sky-500/40 bg-sky-500/10' }, { t: '16:00', l: 'Pneus X1', s: 'border-amber-500/40 bg-amber-500/10' }],
    [{ t: '08:00', l: 'Révision Captur', s: 'border-emerald-500/40 bg-emerald-500/10' }, { t: '10:30', l: 'Clim 5008', s: 'border-sky-500/40 bg-sky-500/10' }, { t: '14:30', l: 'Embrayage C3', s: 'border-orange-500/40 bg-orange-500/10' }],
    [{ t: '09:30', l: 'Vidange Golf 8', s: 'border-sky-500/40 bg-sky-500/10' }, { t: '12:00', l: 'Diag 3008', s: 'border-violet-500/40 bg-violet-500/10' }, { t: '15:00', l: 'Freins A3', s: 'border-orange-500/40 bg-orange-500/10' }],
    [{ t: '08:30', l: 'Pneus hiver ×4', s: 'border-amber-500/40 bg-amber-500/10' }, { t: '11:30', l: 'Révision Yaris', s: 'border-emerald-500/40 bg-emerald-500/10' }, { t: '14:00', l: 'Diag Model 3', s: 'border-violet-500/40 bg-violet-500/10' }],
    [{ t: '09:00', l: 'CT Clio IV', s: 'border-emerald-500/40 bg-emerald-500/10' }, { t: '10:00', l: 'Vidange Duster', s: 'border-sky-500/40 bg-sky-500/10' }],
  ];
  const mecs = [{ n: 'Karim', c: 'bg-sky-500' }, { n: 'Sophie', c: 'bg-orange-500' }, { n: 'Mehdi', c: 'bg-violet-500' }, { n: 'Julien', c: 'bg-emerald-500' }];
  return (
    <div className={shell}>
      <Sidebar />
      <div className={main}>
        <Topbar title="Planning atelier" subtitle="Semaine 46 — 4 mécaniciens • 68 rendez-vous" />
        <div className={body}>
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 p-1">
              <span className="rounded-md p-1 text-zinc-400"><ChevronLeft size={13} /></span>
              <span className="px-1 text-[0.68rem] font-bold text-white">9 – 14 novembre 2026</span>
              <span className="rounded-md p-1 text-zinc-400"><ChevronRight size={13} /></span>
            </span>
            <span className="rounded-lg bg-gradient-to-r from-amber-400 to-orange-600 px-2.5 py-1.5 text-[0.65rem] font-bold text-black">+ Nouveau RDV</span>
            <span className="ml-auto hidden gap-3 lg:flex">{mecs.map((m) => (<span key={m.n} className="flex items-center gap-1.5 text-[0.62rem] text-zinc-400"><i className={`h-2 w-2 rounded-full ${m.c}`} />{m.n}</span>))}</span>
          </div>
          <div className="mt-2.5 grid grid-cols-3 gap-2 lg:grid-cols-6">
            {days.map((d, di) => (
              <div key={d} className={`overflow-hidden rounded-xl border bg-[#12131A] ${di === 4 ? 'border-orange-500/50' : 'border-white/5'}`}>
                <p className={`px-2 py-1.5 text-center text-[0.62rem] font-bold ${di === 4 ? 'bg-orange-500/15 text-orange-300' : 'text-zinc-400'}`}>{d}{di === 4 && ' •'}</p>
                <div className="space-y-1.5 p-1.5">
                  {cols[di].map((a, i) => (
                    <div key={i} className={`rounded-lg border border-l-2 p-1.5 ${a.s}`}>
                      <p className="text-[0.6rem] font-bold text-white">{a.t}</p>
                      <p className="truncate text-[0.6rem] text-zinc-400">{a.l}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2.5 flex items-center gap-2 rounded-xl border border-white/5 bg-[#12131A] px-3 py-2">
            <Clock size={13} className="text-orange-400" />
            <p className="text-[0.65rem] text-zinc-400"><span className="font-bold text-white">Taux de remplissage : 94 %</span> — 3 créneaux libres vendredi après-midi</p>
            <span className="ml-auto rounded-md bg-white/5 px-2 py-1 text-[0.6rem] font-semibold text-zinc-300">Optimiser</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ClientsMockup() {
  const rows = [
    { init: 'SB', name: 'Sophie Bernard', phone: '06 12 44 90 18', cars: '2 • GH-204-KL, KL-771-AB', visit: '08 nov. 2026', total: '2 480 €', tag: 'VIP', cls: 'bg-amber-500/15 text-amber-300 ring-amber-500/30', grad: 'from-sky-400 to-blue-600' },
    { init: 'LM', name: 'Lucas Moreau', phone: '07 62 10 55 41', cars: '1 • AB-913-XZ', visit: '11 nov. 2026', total: '890 €', tag: 'Actif', cls: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30', grad: 'from-emerald-400 to-teal-600' },
    { init: 'KD', name: 'Kadiatou Diallo', phone: '06 98 33 17 62', cars: '1 • FR-555-EV', visit: '05 nov. 2026', total: '1 120 €', tag: 'Actif', cls: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30', grad: 'from-violet-400 to-purple-600' },
    { init: 'MP', name: 'Marc Petit', phone: '06 45 78 29 03', cars: '3 • TM-882-QQ…', visit: '12 nov. 2026', total: '3 940 €', tag: 'VIP', cls: 'bg-amber-500/15 text-amber-300 ring-amber-500/30', grad: 'from-orange-400 to-red-600' },
    { init: 'AR', name: 'Anna Rousseau', phone: '07 11 90 64 28', cars: '1 • VX-310-RT', visit: '28 oct. 2026', total: '640 €', tag: 'À relancer', cls: 'bg-sky-500/15 text-sky-300 ring-sky-500/30', grad: 'from-pink-400 to-rose-600' },
    { init: 'TD', name: 'Thomas Dubois', phone: '06 77 51 09 94', cars: '2 • EE-402-PP…', visit: '19 oct. 2026', total: '1 705 €', tag: 'En retard', cls: 'bg-red-500/15 text-red-300 ring-red-500/30', grad: 'from-amber-400 to-orange-600' },
  ];
  return (
    <div className={shell}>
      <Sidebar />
      <div className={main}>
        <Topbar title="Clients" subtitle="1 284 clients • 214 nouveaux cette année" />
        <div className={body}>
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex flex-1 items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-[0.68rem] text-zinc-500 sm:max-w-xs"><Search size={12} /> Rechercher un client, une plaque…</span>
            <span className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-2 text-[0.65rem] text-zinc-400">Tous les statuts</span>
            <span className="ml-auto flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-orange-600 px-2.5 py-2 text-[0.65rem] font-bold text-black"><Plus size={13} /> Nouveau client</span>
          </div>
          <div className="mt-2.5 overflow-hidden rounded-xl border border-white/5 bg-[#12131A]">
            <div className="hidden grid-cols-12 gap-2 border-b border-white/5 px-3 py-2 text-[0.6rem] font-bold uppercase tracking-wider text-zinc-500 sm:grid">
              <span className="col-span-3">Client</span><span className="col-span-3">Véhicules</span><span className="col-span-2">Dernière visite</span><span className="col-span-2">Total facturé</span><span className="col-span-2">Statut</span>
            </div>
            {rows.map((r) => (
              <div key={r.name} className="grid grid-cols-2 items-center gap-2 border-b border-white/5 px-3 py-2.5 last:border-0 sm:grid-cols-12">
                <span className="col-span-2 flex items-center gap-2 sm:col-span-3">
                  <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br text-[0.65rem] font-black text-white ${r.grad}`}>{r.init}</span>
                  <span className="min-w-0"><span className="block truncate text-[0.7rem] font-bold text-white">{r.name}</span><span className="flex items-center gap-1 text-[0.62rem] text-zinc-500"><Phone size={10} />{r.phone}</span></span>
                </span>
                <span className="truncate text-[0.65rem] text-zinc-400 sm:col-span-3">{r.cars}</span>
                <span className="text-[0.65rem] text-zinc-400 sm:col-span-2">{r.visit}</span>
                <span className="text-[0.7rem] font-bold text-white sm:col-span-2">{r.total}</span>
                <span className="sm:col-span-2"><span className={`rounded-full px-2 py-0.5 text-[0.6rem] font-bold ring-1 ${r.cls}`}>{r.tag}</span></span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function VehiclesMockup() {
  const cars = [
    { model: 'Peugeot 3008 GT', plate: 'GH-204-KL', owner: 'S. Bernard', km: '86 400 km', next: 'Vidange dans 3 200 km', pct: 72, status: 'À l’atelier', cls: 'bg-sky-500/15 text-sky-300 ring-sky-500/30' },
    { model: 'Renault Clio V', plate: 'AB-913-XZ', owner: 'L. Moreau', km: '42 150 km', next: 'CT le 02/2027', pct: 45, status: 'En attente', cls: 'bg-amber-500/15 text-amber-300 ring-amber-500/30' },
    { model: 'Tesla Model 3', plate: 'FR-555-EV', owner: 'K. Diallo', km: '61 900 km', next: 'Freins à contrôler', pct: 88, status: 'Diagnostic', cls: 'bg-violet-500/15 text-violet-300 ring-violet-500/30' },
    { model: 'Dacia Duster', plate: 'TM-882-QQ', owner: 'M. Petit', km: '118 200 km', next: 'Distribution faite', pct: 100, status: 'Prêt', cls: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30' },
    { model: 'BMW X1 xDrive', plate: 'VX-310-RT', owner: 'A. Rousseau', km: '74 600 km', next: 'Pneus hiver conseillés', pct: 60, status: 'À l’atelier', cls: 'bg-sky-500/15 text-sky-300 ring-sky-500/30' },
    { model: 'Toyota Yaris', plate: 'HJ-118-NB', owner: 'P. Lambert', km: '35 800 km', next: 'Révision dans 5 000 km', pct: 30, status: 'Suivi', cls: 'bg-white/5 text-zinc-300 ring-white/15' },
  ];
  return (
    <div className={shell}>
      <Sidebar />
      <div className={main}>
        <Topbar title="Véhicules" subtitle="1 932 véhicules suivis • VIN, kilométrage et historique" />
        <div className={body}>
          <div className="flex flex-wrap items-center gap-2">
            {['Tous (1 932)', 'À l’atelier (18)', 'CT < 3 mois (64)', 'Entretien dû (112)'].map((f, i) => (
              <span key={f} className={`rounded-full px-3 py-1.5 text-[0.62rem] font-bold ${i === 0 ? 'bg-gradient-to-r from-amber-400 to-orange-600 text-black' : 'border border-white/10 bg-white/5 text-zinc-400'}`}>{f}</span>
            ))}
            <span className="ml-auto flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-[0.62rem] text-zinc-300"><Wrench size={12} className="text-orange-400" /> Décoder un VIN</span>
          </div>
          <div className="mt-2.5 grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {cars.map((c) => (
              <div key={c.plate} className="rounded-xl border border-white/5 bg-[#12131A] p-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-white/10 to-white/5 text-orange-400 ring-1 ring-white/10"><Car size={17} /></span>
                  <span className={`rounded-full px-2 py-0.5 text-[0.58rem] font-bold ring-1 ${c.cls}`}>{c.status}</span>
                </div>
                <p className="mt-2 text-[0.72rem] font-bold text-white">{c.model}</p>
                <div className="mt-1.5 flex items-center gap-2">
                  <span className="flex items-center overflow-hidden rounded border border-white/20 font-mono text-[0.6rem] font-bold">
                    <i className="bg-blue-700 px-1 py-0.5 text-white not-italic">F</i>
                    <i className="bg-white px-1.5 py-0.5 text-zinc-900 not-italic">{c.plate}</i>
                  </span>
                  <span className="text-[0.6rem] text-zinc-500">{c.owner}</span>
                </div>
                <div className="mt-2 flex items-center justify-between text-[0.6rem] text-zinc-500"><span>{c.km}</span><span className="text-zinc-400">{c.next}</span></div>
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10"><span className="block h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500" style={{ width: `${c.pct}%` }} /></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function BillingMockup() {
  const invoices = [
    { n: 'FAC-2026-1841', client: 'S. Bernard — 3008', amt: '486,20 €', s: 'Payée', cls: 'bg-emerald-500/15 text-emerald-300' },
    { n: 'FAC-2026-1840', client: 'M. Petit — Duster', amt: '1 129,00 €', s: 'Payée', cls: 'bg-emerald-500/15 text-emerald-300' },
    { n: 'FAC-2026-1839', client: 'L. Moreau — Clio V', amt: '312,50 €', s: 'En attente', cls: 'bg-amber-500/15 text-amber-300' },
    { n: 'FAC-2026-1838', client: 'T. Dubois — 208', amt: '745,80 €', s: 'En retard', cls: 'bg-red-500/15 text-red-300' },
    { n: 'FAC-2026-1837', client: 'K. Diallo — Model 3', amt: '198,00 €', s: 'Payée', cls: 'bg-emerald-500/15 text-emerald-300' },
  ];
  const lines = [
    { d: 'Vidange + filtre à huile (5W30)', q: '1', p: '129,00 €', t: '129,00 €' },
    { d: 'Plaquettes de frein avant (Brembo)', q: '1', p: '89,90 €', t: '89,90 €' },
    { d: 'Main d’œuvre — 2,5 h', q: '2,5', p: '68,00 €', t: '170,00 €' },
    { d: 'Diagnostic électronique', q: '1', p: '45,00 €', t: '45,00 €' },
  ];
  return (
    <div className={shell}>
      <Sidebar />
      <div className={main}>
        <Topbar title="Facturation" subtitle="Devis, factures, avoirs — 48 290 € encaissés en novembre" />
        <div className={`${body} grid gap-2.5 lg:grid-cols-5`}>
          <div className="overflow-hidden rounded-xl border border-white/5 bg-[#12131A] lg:col-span-2">
            <div className="flex items-center justify-between border-b border-white/5 px-3 py-2">
              <p className="text-[0.7rem] font-bold text-white">Factures récentes</p>
              <span className="flex items-center gap-1 rounded-md bg-gradient-to-r from-amber-400 to-orange-600 px-2 py-1 text-[0.6rem] font-bold text-black"><Plus size={11} /> Facture</span>
            </div>
            {invoices.map((f, i) => (
              <div key={f.n} className={`flex items-center gap-2 border-b border-white/5 px-3 py-2 ${i === 0 ? 'bg-orange-500/5' : ''}`}>
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/5 text-zinc-400"><FileText size={14} /></span>
                <span className="min-w-0 flex-1"><span className="block text-[0.65rem] font-bold text-white">{f.n}</span><span className="block truncate text-[0.6rem] text-zinc-500">{f.client}</span></span>
                <span className="text-right"><span className="block text-[0.65rem] font-bold text-white">{f.amt}</span><span className={`rounded-full px-1.5 py-px text-[0.55rem] font-bold ${f.cls}`}>{f.s}</span></span>
              </div>
            ))}
          </div>
          <div className="relative hidden overflow-hidden rounded-xl border border-white/5 bg-[#F5F3EF] p-4 text-zinc-800 sm:block lg:col-span-3">
            <div className="flex items-start justify-between">
              <div><p className="text-[0.75rem] font-black text-zinc-900">GARAGE MARTIN</p><p className="text-[0.6rem] text-zinc-500">24 rue des Artisans, 69007 Lyon</p></div>
              <div className="text-right"><p className="text-[0.75rem] font-black text-zinc-900">FACTURE</p><p className="text-[0.6rem] font-semibold text-orange-600">FAC-2026-1841</p></div>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2 text-[0.6rem]">
              <div className="rounded-lg bg-zinc-900/[0.04] p-2"><p className="font-bold text-zinc-500">Facturé à</p><p className="font-bold text-zinc-900">Sophie Bernard</p><p className="text-zinc-500">Peugeot 3008 • GH-204-KL</p></div>
              <div className="rounded-lg bg-zinc-900/[0.04] p-2"><p className="font-bold text-zinc-500">Dates</p><p className="text-zinc-700">Émise le 12/11/2026</p><p className="text-zinc-700">Échéance le 12/12/2026</p></div>
            </div>
            <div className="mt-2 overflow-hidden rounded-lg border border-zinc-900/10">
              <div className="grid grid-cols-12 bg-zinc-900 px-2 py-1.5 text-[0.55rem] font-bold uppercase tracking-wide text-white"><span className="col-span-6">Désignation</span><span className="col-span-2 text-center">Qté</span><span className="col-span-2 text-right">P.U.</span><span className="col-span-2 text-right">Total</span></div>
              {lines.map((l) => (
                <div key={l.d} className="grid grid-cols-12 border-t border-zinc-900/5 bg-white px-2 py-1.5 text-[0.6rem]"><span className="col-span-6 font-medium text-zinc-700">{l.d}</span><span className="col-span-2 text-center text-zinc-500">{l.q}</span><span className="col-span-2 text-right text-zinc-500">{l.p}</span><span className="col-span-2 text-right font-bold text-zinc-900">{l.t}</span></div>
              ))}
            </div>
            <div className="mt-2 flex items-end justify-between">
              <span className="flex rotate-[-6deg] items-center gap-1 rounded-lg border-2 border-emerald-600 px-2.5 py-1 text-[0.7rem] font-black tracking-widest text-emerald-700"><Check size={13} strokeWidth={3} /> PAYÉE</span>
              <div className="text-right text-[0.62rem]"><p className="text-zinc-500">Total HT : 433,90 € • TVA 20 % : 86,78 €</p><p className="text-[0.95rem] font-black text-zinc-900">Total TTC : 520,68 €</p></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
