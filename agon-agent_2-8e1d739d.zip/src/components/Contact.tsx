import { useState } from 'react';
import type { FormEvent } from 'react';
import { Send, Phone, Mail, Clock, Check, Loader2, CalendarCheck2, FileText, Database } from 'lucide-react';
import { SectionTag, Reveal } from './ui';
import { CONTACT_EMAIL, CONTACT_PHONE } from '../lib/constants';

const PERKS = [
  { icon: CalendarCheck2, t: 'Démo 30 min en visio', d: 'Avec un expert garage, sur vos cas réels.' },
  { icon: FileText, t: 'Devis sur mesure', d: 'Selon vos postes, vos mécaniciens, vos besoins.' },
  { icon: Database, t: 'Reprise de données offerte', d: 'Depuis Excel ou votre ancien logiciel.' },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', garage_name: '', message: '' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!form.name.trim() || !form.email.trim()) {
      setError('Merci de renseigner au minimum votre nom et votre email.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      setError('Merci de saisir une adresse email valide.');
      return;
    }
    setSending(true);
    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, type: 'demo' }),
      });
      if (!res.ok) throw new Error('Erreur');
      setSent(true);
    } catch {
      setError('L’envoi a échoué. Réessayez ou appelez-nous directement.');
    } finally {
      setSending(false);
    }
  };

  const inputCls = 'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-zinc-600 outline-none transition-colors focus:border-orange-500/60 focus:bg-white/[0.07]';

  return (
    <section id="contact" className="relative scroll-mt-20 border-t border-white/5 bg-[#0B0C10] py-20 md:py-28">
      <div className="mx-auto grid max-w-7xl items-start gap-10 px-5 lg:grid-cols-2 lg:px-8">
        <Reveal>
          <SectionTag>Démo personnalisée</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:leading-[1.1]">
            Voyez GarageFall <span className="gradient-text">sur votre activité</span>
          </h2>
          <p className="mt-4 text-zinc-400">Laissez-nous vos coordonnées : un expert vous recontacte sous 24 h ouvrées pour une démonstration adaptée à votre garage.</p>
          <div className="mt-8 space-y-4">
            {PERKS.map((p) => (
              <div key={p.t} className="flex items-start gap-4 rounded-2xl border border-white/10 bg-[#101116] p-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-500/15 text-orange-400 ring-1 ring-orange-500/30"><p.icon size={20} /></span>
                <div><p className="text-sm font-bold text-white">{p.t}</p><p className="text-sm text-zinc-500">{p.d}</p></div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-col gap-3 text-sm sm:flex-row sm:flex-wrap sm:gap-6">
            <a href={`tel:${CONTACT_PHONE.replace(/\s/g, '')}`} className="inline-flex items-center gap-2 font-semibold text-zinc-300 hover:text-white"><Phone size={16} className="text-orange-400" /> {CONTACT_PHONE}</a>
            <a href={`mailto:${CONTACT_EMAIL}`} className="inline-flex items-center gap-2 font-semibold text-zinc-300 hover:text-white"><Mail size={16} className="text-orange-400" /> {CONTACT_EMAIL}</a>
            <span className="inline-flex items-center gap-2 text-zinc-500"><Clock size={16} /> Lun – Sam • 8h – 19h</span>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="rounded-2xl border border-white/10 bg-[#101116] p-6 sm:p-8">
            {sent ? (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/40"><Check size={30} strokeWidth={3} /></span>
                <h3 className="font-display mt-5 text-2xl font-bold text-white">Demande bien reçue !</h3>
                <p className="mt-2 max-w-sm text-sm text-zinc-400">Merci {form.name.split(' ')[0]}. Un expert GarageFall vous recontacte sous 24 h ouvrées pour planifier votre démo.</p>
                <button onClick={() => { setSent(false); setForm({ name: '', email: '', phone: '', garage_name: '', message: '' }); }} className="btn-ghost mt-6">Faire une autre demande</button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4" noValidate>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-zinc-400">Nom complet *</label>
                    <input className={inputCls} placeholder="Martin Dupont" value={form.name} onChange={set('name')} />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-zinc-400">Email pro *</label>
                    <input type="email" className={inputCls} placeholder="martin@garage-martin.fr" value={form.email} onChange={set('email')} />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-zinc-400">Téléphone</label>
                    <input type="tel" className={inputCls} placeholder="06 12 34 56 78" value={form.phone} onChange={set('phone')} />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-zinc-400">Nom du garage</label>
                    <input className={inputCls} placeholder="Garage Martin" value={form.garage_name} onChange={set('garage_name')} />
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-zinc-400">Votre besoin</label>
                  <textarea rows={4} className={`${inputCls} resize-none`} placeholder="Ex : 3 mécaniciens, 2 ponts, je veux remplacer Excel et automatiser mes rappels de RDV…" value={form.message} onChange={set('message')} />
                </div>
                {error && <p className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}
                <button type="submit" disabled={sending} className="btn-primary w-full justify-center disabled:opacity-60">
                  {sending ? <Loader2 size={17} className="animate-spin" /> : <Send size={16} />}
                  {sending ? 'Envoi en cours…' : 'Recevoir ma démo gratuite'}
                </button>
                <p className="text-center text-xs text-zinc-600">En envoyant ce formulaire, vous acceptez d’être recontacté par GarageFall. Vos données restent en France et ne sont jamais revendues.</p>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
