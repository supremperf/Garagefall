import { motion } from 'framer-motion';
import { Download, Play, ShieldCheck, Zap, Headset, RefreshCw, TrendingUp, CalendarCheck2 } from 'lucide-react';
import DashboardMockup from './Mockups';
import { DOWNLOAD_URL, DOWNLOAD_LABEL } from '../lib/constants';

const TRUST = [
  { icon: Zap, label: 'Essai gratuit 14 jours' },
  { icon: ShieldCheck, label: 'Sans carte bancaire' },
  { icon: Headset, label: 'Support 7j/7 en français' },
  { icon: RefreshCw, label: 'Mises à jour incluses' },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-[130px] pb-10 md:pt-[150px]">
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute inset-0 bg-grid" />
        <div className="absolute -top-40 left-1/2 h-[560px] w-[900px] -translate-x-1/2 rounded-full bg-orange-600/20 blur-[140px]" />
        <div className="absolute top-40 -left-40 h-[420px] w-[420px] rounded-full bg-amber-500/10 blur-[120px]" />
        <div className="absolute top-64 -right-40 h-[420px] w-[420px] rounded-full bg-red-600/10 blur-[120px]" />
        <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-black/60 to-transparent" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <a href="#telechargement" className="inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/5 py-1.5 pr-4 pl-1.5 text-xs font-medium text-zinc-300 backdrop-blur transition-colors hover:border-orange-500/40 hover:text-white">
              <span className="rounded-full bg-gradient-to-r from-amber-400 to-orange-600 px-2.5 py-1 text-[0.65rem] font-bold uppercase tracking-wider text-black">Nouveau</span>
              Version 4.2 — rappels SMS automatiques
              <span className="text-orange-400">→</span>
            </a>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.08 }}
            className="font-display mt-6 text-[2.6rem] leading-[1.04] font-bold tracking-tight text-white sm:text-6xl lg:text-[4.6rem]"
          >
            Le logiciel qui fait tourner <span className="gradient-text">votre garage</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.16 }}
            className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-zinc-400 md:text-lg"
          >
            Planning, clients, véhicules, ordres de réparation, facturation et stock pièces —
            GarageFall centralise toute votre activité dans un seul outil Windows, rapide et pensé pour l’atelier.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.24 }}
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className="btn-primary btn-lg w-full sm:w-auto">
              <Download size={19} strokeWidth={2.5} />
              {DOWNLOAD_LABEL}
            </a>
            <a href="#logiciel" className="btn-ghost btn-lg w-full sm:w-auto">
              <Play size={18} className="fill-current" />
              Voir le logiciel
            </a>
          </motion.div>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mt-3 text-xs text-zinc-500">
            Windows 10 / 11 • Fichier EXE • Installation en 3 minutes
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-x-7 gap-y-3"
          >
            {TRUST.map((t) => (
              <span key={t.label} className="inline-flex items-center gap-2 text-[0.83rem] font-medium text-zinc-400">
                <t.icon size={15} className="text-orange-400" />
                {t.label}
              </span>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto mt-14 max-w-6xl"
        >
          <div className="pointer-events-none absolute -inset-x-8 -top-8 bottom-10 rounded-[32px] bg-gradient-to-b from-orange-500/15 via-transparent to-transparent blur-2xl" aria-hidden />
          <div className="browser-frame relative overflow-hidden">
            <div className="flex items-center gap-3 border-b border-white/10 bg-[#101117] px-4 py-3">
              <span className="flex gap-1.5">
                <i className="h-3 w-3 rounded-full bg-[#FF5F57]" />
                <i className="h-3 w-3 rounded-full bg-[#FEBC2E]" />
                <i className="h-3 w-3 rounded-full bg-[#28C840]" />
              </span>
              <span className="mx-auto hidden items-center gap-2 rounded-md border border-white/10 bg-white/5 px-4 py-1 text-xs text-zinc-400 sm:flex">
                <ShieldCheck size={12} className="text-emerald-400" /> app.garagefall.fr — Tableau de bord
              </span>
              <span className="ml-auto flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[0.65rem] font-semibold text-emerald-300 sm:ml-0">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> En direct
              </span>
            </div>
            <div className="pointer-events-none select-none">
              <DashboardMockup />
            </div>
          </div>

          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -left-4 top-24 hidden w-52 rounded-2xl border border-white/10 bg-[#12131A]/95 p-4 shadow-2xl shadow-black/60 backdrop-blur lg:block xl:-left-16"
          >
            <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400"><TrendingUp size={15} /></span>
              Chiffre d’affaires
            </div>
            <p className="font-display mt-2 text-2xl font-bold text-white">48 290 €</p>
            <p className="mt-0.5 text-xs font-semibold text-emerald-400">+32 % ce mois</p>
            <div className="mt-3 flex h-9 items-end gap-1">
              {[35, 55, 42, 68, 58, 80, 72, 95].map((h, i) => (
                <span key={i} className="flex-1 rounded-sm bg-gradient-to-t from-orange-600/40 to-amber-400/90" style={{ height: `${h}%` }} />
              ))}
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            className="absolute -right-4 top-40 hidden w-56 rounded-2xl border border-white/10 bg-[#12131A]/95 p-4 shadow-2xl shadow-black/60 backdrop-blur lg:block xl:-right-14"
          >
            <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-orange-500/15 text-orange-400"><CalendarCheck2 size={15} /></span>
              Aujourd’hui à l’atelier
            </div>
            <p className="font-display mt-2 text-2xl font-bold text-white">12 rendez-vous</p>
            <div className="mt-3 space-y-2">
              {[
                { t: '09:00', l: 'Vidange — Peugeot 3008', c: 'bg-sky-500' },
                { t: '10:30', l: 'Freinage — Clio V', c: 'bg-orange-500' },
                { t: '14:00', l: 'Diag — Tesla Model 3', c: 'bg-violet-500' },
              ].map((r) => (
                <div key={r.t} className="flex items-center gap-2 rounded-lg bg-white/5 px-2.5 py-1.5 text-[0.7rem]">
                  <span className={`h-2 w-2 rounded-full ${r.c}`} />
                  <span className="font-semibold text-zinc-300">{r.t}</span>
                  <span className="truncate text-zinc-500">{r.l}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
