import { useEffect, useState } from 'react';
import { Download, ShieldCheck, Zap, AppWindow, Cpu, HardDrive, Wifi, Check, Loader2 } from 'lucide-react';
import { SectionTag, Reveal } from './ui';
import { DOWNLOAD_URL, DOWNLOAD_LABEL } from '../lib/constants';

type V = { version: string; release_date: string; size_mb: string; requirements: string; notes: string[] };

const STEPS = [
  { n: '1', t: 'Téléchargez le fichier EXE', d: 'Cliquez sur le bouton — le téléchargement démarre instantanément.' },
  { n: '2', t: 'Lancez l’installation', d: 'Double-cliquez, suivez les 3 écrans. Aucun réglage technique.' },
  { n: '3', t: 'Connectez-vous et démarrez', d: 'Créez votre compte, importez vos données, planifiez vos RDV.' },
];

const REQ_ICONS = [AppWindow, Cpu, HardDrive, Wifi];

export default function DownloadSection() {
  const [version, setVersion] = useState<V | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/version')
      .then((r) => r.json())
      .then((d) => { if (d && d.version) setVersion(d); })
      .catch(() => undefined)
      .finally(() => setLoading(false));
  }, []);

  const reqs = version?.requirements?.split('|') ?? ['Windows 10 / 11 (64 bits)', '4 Go de RAM minimum', '500 Mo d’espace disque', 'Connexion internet'];

  return (
    <section id="telechargement" className="relative scroll-mt-20 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[28px] border border-orange-500/25 bg-gradient-to-b from-[#151310] to-[#0D0C0A] p-8 md:p-12 lg:p-16">
            <div className="pointer-events-none absolute inset-0" aria-hidden>
              <div className="absolute -top-32 left-1/2 h-[380px] w-[700px] -translate-x-1/2 rounded-full bg-orange-600/20 blur-[120px]" />
              <div className="absolute inset-0 bg-grid opacity-60" />
            </div>
            <div className="relative grid items-center gap-12 lg:grid-cols-2">
              <div>
                <SectionTag>Téléchargement Windows</SectionTag>
                <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.7rem] lg:leading-[1.1]">
                  Prêt en 3 minutes. <span className="gradient-text">Essayez GarageFall.</span>
                </h2>
                <p className="mt-4 text-zinc-400">Un seul fichier d’installation, signé et vérifié. Vos 14 jours d’essai complet démarrent au premier lancement.</p>

                <div className="mt-7 space-y-4">
                  {STEPS.map((s) => (
                    <div key={s.n} className="flex items-start gap-4">
                      <span className="font-display flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 text-sm font-black text-black">{s.n}</span>
                      <div><p className="text-sm font-bold text-white">{s.t}</p><p className="text-sm text-zinc-500">{s.d}</p></div>
                    </div>
                  ))}
                </div>

                <div className="mt-8">
                  {loading ? (
                    <span className="btn-primary btn-lg opacity-70"><Loader2 size={18} className="animate-spin" /> Chargement…</span>
                  ) : (
                    <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className="btn-primary btn-xl group">
                      <Download size={20} strokeWidth={2.5} className="transition-transform group-hover:translate-y-0.5" />
                      <span className="flex flex-col items-start leading-tight">
                        {DOWNLOAD_LABEL}
                        <span className="text-[0.7rem] font-medium text-black/70">Version {version?.version ?? '4.2.0'} • EXE • {version?.size_mb ?? '148'} Mo</span>
                      </span>
                    </a>
                  )}
                  <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-zinc-500">
                    <span className="inline-flex items-center gap-1.5"><ShieldCheck size={14} className="text-emerald-400" /> Fichier signé — 0 menace détectée</span>
                    <span className="inline-flex items-center gap-1.5"><Zap size={14} className="text-amber-400" /> Installation en 3 minutes</span>
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#101116] shadow-2xl shadow-black/60">
                  <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 text-sm font-black text-black">G</span>
                    <div><p className="text-xs font-bold text-white">GarageFall — Installation</p><p className="text-[0.65rem] text-zinc-500">GarageFall_Setup_{version?.version ?? '4.2.0'}.exe</p></div>
                    <span className="ml-auto rounded-full bg-emerald-500/15 px-2.5 py-1 text-[0.62rem] font-bold text-emerald-300">Éditeur vérifié</span>
                  </div>
                  <div className="space-y-2.5 p-5">
                    {['Téléchargement du package', 'Vérification de la signature', 'Installation des composants', 'Configuration du poste'].map((l, i) => (
                      <div key={l} className="flex items-center gap-3 text-xs">
                        <span className={`flex h-6 w-6 items-center justify-center rounded-full ${i < 2 ? 'bg-emerald-500/20 text-emerald-400' : i === 2 ? 'bg-orange-500/20 text-orange-400' : 'bg-white/5 text-zinc-500'}`}>
                          {i < 2 ? <Check size={13} strokeWidth={3} /> : i === 2 ? <Loader2 size={13} className="animate-spin" /> : <span className="text-[0.6rem] font-bold">{i + 1}</span>}
                        </span>
                        <span className={i <= 2 ? 'font-medium text-zinc-200' : 'text-zinc-600'}>{l}</span>
                        {i < 2 && <span className="ml-auto text-[0.62rem] font-semibold text-emerald-400">Terminé</span>}
                        {i === 2 && <span className="ml-auto text-[0.62rem] font-semibold text-orange-300">72 %</span>}
                      </div>
                    ))}
                    <div className="pt-1">
                      <div className="h-2 overflow-hidden rounded-full bg-white/10">
                        <div className="progress-fill h-full w-[72%] rounded-full bg-gradient-to-r from-amber-400 to-orange-500" />
                      </div>
                      <p className="mt-2 text-[0.65rem] text-zinc-500">Installation de « Module Planning »… 48 s restantes</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2.5">
                  {reqs.map((r, i) => {
                    const Icon = REQ_ICONS[i % REQ_ICONS.length];
                    return (
                      <div key={r} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5">
                        <Icon size={16} className="shrink-0 text-orange-400" />
                        <span className="text-xs font-medium text-zinc-300">{r}</span>
                      </div>
                    );
                  })}
                </div>
                {version && (
                  <p className="mt-3 text-center text-[0.7rem] text-zinc-600">Version {version.version} • Publiée le {version.release_date}</p>
                )}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
