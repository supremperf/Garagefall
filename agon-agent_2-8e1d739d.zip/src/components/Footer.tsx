import { Facebook, Instagram, Linkedin, Youtube, Download, MapPin } from 'lucide-react';
import Logo from './Logo';
import { DOWNLOAD_URL, DOWNLOAD_LABEL, CONTACT_EMAIL, CONTACT_PHONE } from '../lib/constants';

const COLS = [
  { title: 'Produit', links: [{ l: 'Logiciel', h: '#logiciel' }, { l: 'Fonctionnalités', h: '#fonctionnalites' }, { l: 'Tarifs', h: '#tarifs' }, { l: 'Téléchargement', h: '#telechargement' }, { l: 'Nouveautés v4.2', h: '#telechargement' }] },
  { title: 'Ressources', links: [{ l: 'Avantages', h: '#avantages' }, { l: 'Avis clients', h: '#avis' }, { l: 'FAQ', h: '#faq' }, { l: 'Démo personnalisée', h: '#contact' }, { l: 'Nous contacter', h: '#contact' }] },
  { title: 'GarageFall', links: [{ l: 'Haut de page', h: '#top' }, { l: 'Mentions légales', h: '#top' }, { l: 'Confidentialité', h: '#top' }, { l: 'CGU', h: '#top' }, { l: 'Cookies', h: '#top' }] },
];

const SOCIALS = [
  { icon: Facebook, label: 'Facebook' },
  { icon: Instagram, label: 'Instagram' },
  { icon: Linkedin, label: 'LinkedIn' },
  { icon: Youtube, label: 'YouTube' },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#060708]">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-12">
          <div className="md:col-span-2 lg:col-span-6">
            <Logo size={40} />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-zinc-500">
              Le logiciel de gestion nouvelle génération pour garages automobiles indépendants. Conçu avec des garagistes, pour des garagistes.
            </p>
            <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className="btn-primary mt-6">
              <Download size={16} strokeWidth={2.5} /> {DOWNLOAD_LABEL}
            </a>
            <div className="mt-6 flex gap-2.5">
              {SOCIALS.map((s) => (
                <a key={s.label} href="#top" aria-label={s.label} className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:border-orange-500/40 hover:text-orange-300">
                  <s.icon size={17} />
                </a>
              ))}
            </div>
          </div>
          {COLS.map((c) => (
            <div key={c.title} className="lg:col-span-2">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-zinc-500">{c.title}</p>
              <ul className="mt-4 space-y-2.5">
                {c.links.map((l) => (
                  <li key={l.l}><a href={l.h} className="text-sm text-zinc-400 transition-colors hover:text-white">{l.l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-7 text-xs text-zinc-600 md:flex-row">
          <p>© 2026 GarageFall SAS — Tous droits réservés.</p>
          <p className="inline-flex flex-wrap items-center justify-center gap-1.5"><MapPin size={13} /> Conçu et hébergé en France • {CONTACT_PHONE} • {CONTACT_EMAIL}</p>
          <p className="inline-flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]" /> Tous les systèmes opérationnels
          </p>
        </div>
      </div>
    </footer>
  );
}
