export const DOWNLOAD_URL = 'https://www.dropbox.com/scl/fo/hsd97bqq9mmfei6whx4jn/AFIoXwVxrSEu1qr0H4cNIpU?rlkey=7yty77pmmh3674rxfzdgq8dbn&st=vjxcud0a&dl=1';
export const DOWNLOAD_LABEL = 'Télécharger GarageFall';
export const APP_NAME = 'GarageFall';
export const CONTACT_EMAIL = 'contact@garagefall.fr';
export const CONTACT_PHONE = '01 84 80 20 40';
