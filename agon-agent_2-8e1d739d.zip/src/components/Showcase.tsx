import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, CalendarDays, Users, Car, Receipt, Check, Download, ShieldCheck } from 'lucide-react';
import DashboardMockup, { PlanningMockup, ClientsMockup, VehiclesMockup, BillingMockup } from './Mockups';
import { SectionTag, Reveal } from './ui';
import { DOWNLOAD_URL } from '../lib/constants';

const TABS = [
  {
    id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, title: 'Pilotez votre garage en un coup d’œil',
    desc: 'Le tableau de bord centralise votre chiffre d’affaires, vos interventions en cours, vos rendez-vous du jour et vos impayés. Chaque matin, vous savez exactement où en est votre atelier.',
    bullets: ['CA temps réel par mécanicien et par prestation', 'Alertes impayés et relances en 1 clic', 'Objectifs mensuels et taux de remplissage', 'Vue atelier : qui fait quoi, sur quel véhicule'],
  },
  {
    id: 'planning', label: 'Planning', icon: CalendarDays, title: 'Un planning qui remplit votre atelier',
    desc: 'Glissez-déposez vos rendez-vous, visualisez la charge de chaque mécanicien et ne laissez plus aucun pont inoccupé. Les rappels SMS automatiques font chuter les lapins de 80 %.',
    bullets: ['Glisser-déposer multi-mécaniciens et multi-ponts', 'Rappels SMS automatiques J-1 et J+1', 'Prise de RDV en ligne synchronisée', 'Vue jour, semaine et charge prévisionnelle'],
  },
  {
    id: 'clients', label: 'Clients', icon: Users, title: 'Connaissez chacun de vos clients',
    desc: 'Fiche client complète : coordonnées, véhicules, historique des interventions, devis, factures et préférences. Retrouvez n’importe quelle information en moins de 3 secondes.',
    bullets: ['Historique complet client + véhicules', 'Segmentation VIP, à relancer, en retard', 'Import Excel et reprise de données offerte', 'Consentements RGPD et preuve horodatée'],
  },
  {
    id: 'vehicules', label: 'Véhicules', icon: Car, title: 'Chaque véhicule suivi au kilomètre près',
    desc: 'VIN décodé automatiquement, kilométrage, historique, échéances de contrôle technique et préconisations constructeur. Anticipez les entretiens et déclenchez des relances ciblées.',
    bullets: ['Décodage VIN automatique (marque, motorisation)', 'Alertes CT, vidange et distribution', 'Historique horodaté de chaque intervention', 'Photos avant / après jointes aux ordres'],
  },
  {
    id: 'facturation', label: 'Facturation', icon: Receipt, title: 'Facturez en 30 secondes, encaissez plus vite',
    desc: 'Transformez un ordre de réparation en facture conforme en un clic : TVA, remises, acomptes et mentions légales gérés. Envoi email, PDF pro et suivi d’encaissement intégrés.',
    bullets: ['Devis vers OR vers facture en 1 clic', 'Factures conformes, TVA et avoirs gérés', 'Encaissements espèces, CB, virement, LOA', 'Relances automatiques des impayés'],
  },
];

function MockupFor({ id }: { id: string }) {
  switch (id) {
    case 'planning': return <PlanningMockup />;
    case 'clients': return <ClientsMockup />;
    case 'vehicules': return <VehiclesMockup />;
    case 'facturation': return <BillingMockup />;
    default: return <DashboardMockup />;
  }
}

export default function Showcase() {
  const [active, setActive] = useState('dashboard');
  const tab = TABS.find((t) => t.id === active) ?? TABS[0];

  return (
    <section id="logiciel" className="relative scroll-mt-20 py-20 md:py-28">
      <div className="pointer-events-none absolute top-0 left-1/2 h-[400px] w-[800px] -translate-x-1/2 rounded-full bg-orange-600/10 blur-[130px]" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Le logiciel</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">
            Cinq modules. Zéro ressaisie. <span className="gradient-text">100 % atelier.</span>
          </h2>
          <p className="mt-4 text-zinc-400">Explorez les écrans réels de GarageFall : chaque module communique avec les autres, vos données circulent sans jamais être retapées.</p>
        </Reveal>

        <Reveal delay={0.1} className="mt-10">
          <div className="mx-auto flex max-w-3xl flex-wrap justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-2 backdrop-blur">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setActive(t.id)}
                className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-200 ${active === t.id ? 'bg-gradient-to-r from-amber-400 to-orange-600 text-black shadow-lg shadow-orange-600/25' : 'text-zinc-400 hover:bg-white/5 hover:text-white'}`}
              >
                <t.icon size={16} />
                {t.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-8 grid items-start gap-6 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="rounded-2xl border border-white/10 bg-[#101116] p-6 lg:p-7 lg:sticky lg:top-24">
              <AnimatePresence mode="wait">
                <motion.div key={active} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.3 }}>
                  <h3 className="font-display text-xl font-bold text-white">{tab.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">{tab.desc}</p>
                  <ul className="mt-5 space-y-3">
                    {tab.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-2.5 text-sm text-zinc-300">
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400"><Check size={12} strokeWidth={3} /></span>
                        {b}
                      </li>
                    ))}
                  </ul>
                  <a href={DOWNLOAD_URL} target="_blank" rel="noopener noreferrer" className="btn-primary mt-6 w-full justify-center">
                    <Download size={16} strokeWidth={2.5} /> Essayer ce module
                  </a>
                  <p className="mt-2.5 text-center text-xs text-zinc-500">Gratuit 14 jours — sans carte bancaire</p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
          <div className="lg:col-span-8">
            <div className="browser-frame overflow-hidden">
              <div className="flex items-center gap-3 border-b border-white/10 bg-[#101117] px-4 py-2.5">
                <span className="flex gap-1.5">
                  <i className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
                  <i className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" />
                  <i className="h-2.5 w-2.5 rounded-full bg-[#28C840]" />
                </span>
                <span className="flex items-center gap-2 text-xs text-zinc-500"><tab.icon size={13} className="text-orange-400" /> GarageFall — {tab.label}</span>
                <span className="ml-auto hidden items-center gap-1.5 text-[0.65rem] text-zinc-500 sm:flex"><ShieldCheck size={12} className="text-emerald-400" /> Données de démonstration</span>
              </div>
              <div className="pointer-events-none select-none">
                <AnimatePresence mode="wait">
                  <motion.div key={active} initial={{ opacity: 0, scale: 0.985 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.99 }} transition={{ duration: 0.35 }}>
                    <MockupFor id={active} />
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
