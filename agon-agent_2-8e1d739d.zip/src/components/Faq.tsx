import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, MessageCircle } from 'lucide-react';
import { SectionTag, Reveal, Skeleton } from './ui';

type F = { id: number; question: string; answer: string; category: string };

export default function Faq() {
  const [faqs, setFaqs] = useState<F[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [open, setOpen] = useState<number | null>(0);

  useEffect(() => {
    fetch('/api/faqs')
      .then((r) => { if (!r.ok) throw new Error('Erreur'); return r.json(); })
      .then((d) => { if (Array.isArray(d)) setFaqs(d); })
      .catch(() => setError('Impossible de charger la FAQ pour le moment.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section id="faq" className="relative scroll-mt-20 border-t border-white/5 bg-[#0B0C10] py-20 md:py-28">
      <div className="mx-auto grid max-w-7xl items-start gap-10 px-5 lg:grid-cols-12 lg:px-8">
        <Reveal className="lg:col-span-5">
          <div className="lg:sticky lg:top-24">
            <SectionTag>FAQ</SectionTag>
            <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:leading-[1.1]">
              Vos questions, <span className="gradient-text">nos réponses</span>
            </h2>
            <p className="mt-4 text-zinc-400">Tout ce que les garagistes nous demandent avant de passer à GarageFall.</p>
            <div className="mt-7 rounded-2xl border border-white/10 bg-[#101116] p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500/15 text-orange-400 ring-1 ring-orange-500/30"><MessageCircle size={20} /></span>
              <p className="font-display mt-4 font-bold text-white">Une autre question ?</p>
              <p className="mt-1 text-sm text-zinc-400">Notre équipe basée en France répond en moins de 2 h ouvrées.</p>
              <a href="#contact" className="btn-ghost mt-4 w-full justify-center">Contacter l’équipe</a>
            </div>
          </div>
        </Reveal>
        <div className="lg:col-span-7">
          {loading ? (
            <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16" />)}</div>
          ) : error ? (
            <p className="rounded-xl border border-red-500/30 bg-red-500/10 p-5 text-center text-sm text-red-300">{error}</p>
          ) : (
            <div className="space-y-3">
              {faqs.map((f, i) => {
                const isOpen = open === i;
                return (
                  <Reveal key={f.id} delay={Math.min(i, 5) * 0.05}>
                    <div className={`overflow-hidden rounded-2xl border transition-colors ${isOpen ? 'border-orange-500/40 bg-[#12131A]' : 'border-white/10 bg-[#101116] hover:border-white/20'}`}>
                      <button onClick={() => setOpen(isOpen ? null : i)} className="flex w-full items-center gap-4 px-5 py-4 text-left sm:px-6 sm:py-5">
                        <span className="flex-1 text-[0.95rem] font-semibold text-white">{f.question}</span>
                        <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-all duration-300 ${isOpen ? 'rotate-45 bg-gradient-to-br from-amber-400 to-orange-600 text-black' : 'bg-white/5 text-zinc-300'}`}>
                          <Plus size={16} strokeWidth={2.5} />
                        </span>
                      </button>
                      <AnimatePresence initial={false}>
                        {isOpen && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: 'easeInOut' }}>
                            <p className="px-5 pb-5 text-sm leading-relaxed text-zinc-400 sm:px-6">{f.answer}</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
