import { useEffect, useState } from 'react';
import { BadgeCheck, Quote } from 'lucide-react';
import { SectionTag, Reveal, Stars, Skeleton } from './ui';

type T = { id: number; name: string; role: string; garage_name: string; city: string; rating: number; content: string; avatar_color: string };

export default function Testimonials() {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/testimonials')
      .then((r) => { if (!r.ok) throw new Error('Erreur'); return r.json(); })
      .then((d) => { if (Array.isArray(d)) setItems(d); })
      .catch(() => setError('Impossible de charger les avis pour le moment.'))
      .finally(() => setLoading(false));
  }, []);

  const initials = (n: string) => n.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();

  return (
    <section id="avis" className="relative scroll-mt-20 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <SectionTag>Témoignages</SectionTag>
          <h2 className="font-display mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">
            Ils ont transformé leur garage <span className="gradient-text">avec GarageFall</span>
          </h2>
          <div className="mt-5 inline-flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-6 py-3">
            <Stars value={5} size={17} />
            <span className="text-sm font-bold text-white">4,9 / 5</span>
            <span className="text-sm text-zinc-500">— 480+ avis vérifiés</span>
          </div>
        </Reveal>

        {loading ? (
          <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-56" />)}
          </div>
        ) : error ? (
          <p className="mt-12 rounded-xl border border-red-500/30 bg-red-500/10 p-5 text-center text-sm text-red-300">{error}</p>
        ) : (
          <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {items.map((t, i) => (
              <Reveal key={t.id} delay={(i % 3) * 0.08}>
                <figure className="flex h-full flex-col rounded-2xl border border-white/10 bg-[#101116] p-6 transition-colors hover:border-orange-500/35">
                  <div className="flex items-center justify-between">
                    <Stars value={t.rating} />
                    <Quote size={20} className="text-orange-500/40" />
                  </div>
                  <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-zinc-300">« {t.content} »</blockquote>
                  <figcaption className="mt-5 flex items-center gap-3 border-t border-white/5 pt-5">
                    <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-sm font-black text-white ${t.avatar_color}`}>
                      {initials(t.name)}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-bold text-white">{t.name}</span>
                      <span className="block truncate text-xs text-zinc-500">{t.role} — {t.garage_name}, {t.city}</span>
                    </span>
                    <BadgeCheck size={18} className="ml-auto shrink-0 text-sky-400" />
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
