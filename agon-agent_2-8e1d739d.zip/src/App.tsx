import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Download } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Showcase from './components/Showcase';
import { StatsBar, Features, Comparison, Workflow } from './components/Sections';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Faq from './components/Faq';
import DownloadSection from './components/Download';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { DOWNLOAD_URL, DOWNLOAD_LABEL } from './lib/constants';

function StickyCta() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => {
      const dl = document.getElementById('telechargement');
      const past = window.scrollY > 750;
      let nearDl = false;
      if (dl) {
        const r = dl.getBoundingClientRect();
        nearDl = r.top < window.innerHeight * 0.6 && r.bottom > window.innerHeight * 0.3;
      }
      setVisible(past && !nearDl);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 24 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-x-4 bottom-4 z-40 sm:inset-x-auto sm:right-6 sm:bottom-6 sm:left-auto"
        >
          <a
            href={DOWNLOAD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary shadow-[0_16px_50px_-12px_rgba(255,106,26,0.6)] sm:rounded-full sm:px-6 sm:py-3.5 w-full justify-center sm:w-auto"
          >
            <Download size={17} strokeWidth={2.5} />
            {DOWNLOAD_LABEL}
            <span className="hidden rounded-full bg-black/25 px-2 py-0.5 text-[0.65rem] font-bold lg:inline">Gratuit 14 j</span>
          </a>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#08090C] font-sans text-zinc-100 antialiased overflow-x-clip">
      <Navbar />
      <main>
        <Hero />
        <StatsBar />
        <Showcase />
        <Features />
        <Comparison />
        <Workflow />
        <Pricing />
        <Testimonials />
        <Faq />
        <DownloadSection />
        <Contact />
      </main>
      <Footer />
      <StickyCta />
    </div>
  );
}
